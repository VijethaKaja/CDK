package com.io;

import com.pojo.Product;

public interface ProductIO {

	Product getProduct(); 									
	void displayProduct(Product product); 					
}